from distutils.core import setup

setup(
    name='InstaF_Python',
    version='0.1',
    packages=['InstaF_Python',],
    license='MIT',
    long_description=open('README.txt').read(),
)
